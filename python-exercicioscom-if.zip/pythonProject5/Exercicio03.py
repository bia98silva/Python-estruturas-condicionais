A = 10
B = 20

novo_A = 20
novo_B = 10

print(f"Os novos valores de a e b foram: A =  {novo_A} B = {novo_B}")